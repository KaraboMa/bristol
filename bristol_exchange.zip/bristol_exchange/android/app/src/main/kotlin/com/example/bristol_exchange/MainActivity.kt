package com.example.bristol_exchange

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
